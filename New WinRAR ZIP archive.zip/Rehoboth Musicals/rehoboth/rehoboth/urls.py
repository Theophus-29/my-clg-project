from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from musical import views 

urlpatterns = [
    
    path('admin/', admin.site.urls),
    path('', views.musical, name='index'),
    path('admin_login/', views.admin_login, name = 'admin_login'),
    path('all_students/', views.all_students, name= 'all_students'),
    path('records/', views.records, name ='records'),
    path('attendance/', views.attendance, name ='attendance'),
    path('batches/', views.batch, name ='batches'),
    path('deletebatch/<int:batch_id>/', views.deletebatch, name ='deletebatch'),
    path('add_batches/', views.add_batches, name ='add_batches'),
    path('edit_batch/<int:batch_id>/', views.edit_batch, name="edit_batch"),
    path('dashboard/', views.dashboard, name ='dashboard'),
    path('staff_details/', views.edit_staff_details, name ='staff_details'),
    path('enquiry/', views.enquiry, name ='enquiry'),
    path('delete_enquiry/<int:id>/', views.delete_enquiry, name='delete_enquiry'),
    path('inactive_students/', views.inactive_students, name='inactive_students'),
    path('new_admission/', views.new_admission, name='new_admission'),
    path('profile/', views.profile, name='profile'),
    path('staff_management/', views.staff_manager, name ='staff_manager'),
    path('staff_admin/', views.satff_admin, name ='staff_admin'),
    path('student/', views.student, name ='student'),
    path('stud_login/', views.stud_login, name='stud_login'),
    path('uploads/', views.uploads, name='uploads'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)