let enquiryCount = {{ enquiries.count }}; // Initialize with the total count of enquiries

        function deleteEnquiry(id) {
            if (confirm('Are you sure you want to delete this enquiry?')) {
                fetch(`/delete_enquiry/${id}/`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRFToken': '{{ csrf_token }}'  // Include CSRF token for security
                    }
                })
                .then(response => response.json())
                .then(data => {
                    const alertBox = document.getElementById('alertBox');
                    const alertMessage = document.getElementById('alertMessage');

                    if (data.success) {
                        alertMessage.textContent = 'Enquiry deleted successfully.';  // Ensure you set a message
                        alertBox.className = 'alert alert-success alert-dismissible fade show';
                        alertBox.style.display = 'block';

                        // Decrease the count and update the display
                        enquiryCount--;
                        updateEnquiryCount();

                        setTimeout(() => {
                            window.location.reload();
                        }, 2000);
                    } else {
                        alertMessage.textContent = 'Error deleting enquiry.';  // Set error message
                        alertBox.className = 'alert alert-danger alert-dismissible fade show';
                        alertBox.style.display = 'block';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    const alertBox = document.getElementById('alertBox');
                    const alertMessage = document.getElementById('alertMessage');
                    alertMessage.textContent = 'An error occurred while deleting the enquiry.';
                    alertBox.className = 'alert alert-danger alert-dismissible fade show';
                    alertBox.style.display = 'block';
                });
            }
        }

        function markAsRead(button) {
            const row = button.closest('tr');
            const checkbox = row.querySelector('.read-checkbox');
            checkbox.checked = true;  // Mark the enquiry as read
            button.disabled = true;    // Disable the button

            const deleteCell = row.querySelector('.delete-cell');
            deleteCell.style.display = 'table-cell'; // Show the delete button
            
            // Update the enquiry count
            enquiryCount++;
            updateEnquiryCount();
        }

        function toggleDeleteButton(checkbox) {
            const row = checkbox.closest('tr');
            const deleteButton = row.querySelector('.delete-button');

            if (checkbox.checked) {
                deleteButton.style.display = 'block';
            } else {
                deleteButton.style.display = 'none';
            }
        }

        function updateEnquiryCount() {
            const enquiryCountBadge = document.getElementById('enquiryCountBadge');
            enquiryCountBadge.textContent = enquiryCount;
        }

        function closeAlert() {
            const alertBox = document.getElementById('alertBox');
            alertBox.style.display = 'none';
        }

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('collapsed');
        }