from django.db import models

class Enquiry(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=255, blank=True, null=True)
    email = models.EmailField(max_length=255, blank=True, null=True)
    message = models.TextField()

    def __str__(self):
        return f"Enquiry from {self.name}"
    
class batches(models.Model):
    batch_name = models.CharField(max_length=100)
    course_name = models.CharField(max_length=100)
    student_count = models.IntegerField(default=0)

    def __str__(self):
        return self.batch_name

# class StudentDetail(models.Model):

#     # Profile Picture
#     profile_picture = models.ImageField(upload_to='profile_pictures/', blank=True, null=True)  # Optional field

#     # Personal Information
#     first_name = models.CharField(max_length=30)
#     last_name = models.CharField(max_length=30, blank=True)
#     gender = models.CharField(max_length=10, choices=[
#         ('Male', 'Male'),
#         ('Female', 'Female'),
#         ('Other', 'Other'),
#     ])
#     date_of_birth = models.DateField()
#     occupation = models.CharField(max_length=20, choices=[
#         ('school', 'School'),
#         ('college', 'College'),
#         ('work', 'Work'),
#         ('other', 'Other'),
#     ])
#     father_name = models.CharField(max_length=50)
#     mother_name = models.CharField(max_length=50)
#     mobile_no1 = models.CharField(max_length=15)
#     mobile_no2 = models.CharField(max_length=15, blank=True)
#     whatsapp_no = models.CharField(max_length=15)
#     email_id = models.EmailField()
#     address = models.TextField()
#     pincode = models.CharField(max_length=10)
#     state = models.CharField(max_length=50)

#     # Course Details
#     course_name = models.CharField(
#         max_length=50,
#         choices=[
#             ('keyboard', 'Keyboard'),
#             ('guitar', 'Guitar'),
#             ('violin', 'Violin'),
#             ('grade', 'Grade'),
#         ],
#         default='select'
#     )
#     batch_name = models.CharField(
#         max_length=50,
#         choices=[
#             ('weekDays', 'WeekDays'),
#             ('weekends', 'WeekEnds'),
#         ],
#         default='select'
#     )
#     fee_type = models.CharField(max_length=20, choices=[
#         ('monthly', 'Monthly'),
#         ('term_fees', 'Term Fees'),
#     ])
#     fees = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)  # Optional field
#     start_date = models.DateField(null=True, blank=True)
#     remarks = models.TextField(blank=True)

#     def __str__(self):
#         return f"{self.first_name} {self.last_name} - {self.course_name}"
