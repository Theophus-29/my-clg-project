from django import forms
from .models import Enquiry, batches

class EnquiryForm(forms.ModelForm):
    class Meta:
        model = Enquiry
        fields = ['name', 'phone', 'email', 'message']

class StudentRegistrationForm(forms.Form):
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]
    
    OCCUPATION_CHOICES = [
        ('school', 'School'),
        ('college', 'College'),
        ('work', 'Work'),
        ('other', 'Other'),
    ]
    
    COURSE_CHOICES = [
        ('keyboard', 'Keyboard'),
        ('guitar', 'Guitar'),
        ('violin', 'Violin'),
        ('grade', 'Grade'),
    ]
    
    BATCH_CHOICES = [
        ('weekDays', 'WeekDays'),
        ('weekends', 'WeekEnds'),
    ]
    
    FEE_TYPE_CHOICES = [
        ('monthly', 'Monthly'),
        ('term_fees', 'Term'),
    ]

    # Fields
    profile_picture = forms.ImageField(required=True)
    first_name = forms.CharField(max_length=50, required=True)
    last_name = forms.CharField(max_length=50, required=False)
    gender = forms.ChoiceField(
        choices=[('', '--Select--')] + GENDER_CHOICES, 
        required=True
    )
    date_of_birth = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}), 
        required=True
    )
    occupation = forms.ChoiceField(
        choices=[('', '--Select--')] + OCCUPATION_CHOICES, 
        required=True
    )
    father_name = forms.CharField(max_length=50, required=True)
    mother_name = forms.CharField(max_length=50, required=True)
    mobile_no1 = forms.CharField(max_length=10, required=True)
    mobile_no2 = forms.CharField(max_length=10, required=False)
    whatsapp_no = forms.CharField(max_length=10, required=True)
    email_id = forms.EmailField(required=True)
    address = forms.CharField(
        widget=forms.Textarea(attrs={'rows': 3}), 
        required=True
    )
    pincode = forms.CharField(max_length=6, required=True)
    state = forms.CharField(max_length=50, required=True)
    course_name = forms.ChoiceField(
        choices=[('', '--Select--')] + COURSE_CHOICES, 
        required=True
    )
    batch_name = forms.ChoiceField(
        choices=[('', '--Select--')] + BATCH_CHOICES, 
        required=True
    )
    fee_type = forms.ChoiceField(
        choices=[('', '--Select--')] + FEE_TYPE_CHOICES, 
        required=True
    )
    fees = forms.DecimalField(max_digits=10, decimal_places=2, required=False)
    start_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}), 
        required=False
    )
    remarks = forms.CharField(widget=forms.Textarea, required=False)

    # Custom Validation for Dropdowns
    def clean(self):
        cleaned_data = super().clean()
        
        for field_name in ['gender', 'occupation', 'course_name', 'batch_name', 'fee_type']:
            if cleaned_data.get(field_name) == "":
                self.add_error(field_name, f"Please select a valid option for {field_name.replace('_', ' ').title()}.")

        return cleaned_data

class BatchForm(forms.ModelForm):
    class Meta:
        model = batches
        fields = ['batch_name', 'course_name', 'student_count'] 