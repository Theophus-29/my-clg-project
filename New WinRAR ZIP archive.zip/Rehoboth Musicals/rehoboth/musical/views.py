from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q
from .models import Enquiry ,batches
from .forms import EnquiryForm, BatchForm, StudentRegistrationForm
import logging

logger = logging.getLogger(__name__)

def musical(request):
    if request.method == "POST":
        form = EnquiryForm(request.POST)
        if form.is_valid():
            form.save()
            msg = 'Your message has been received and you will be reviewed shortly.'
    else:
        form = EnquiryForm()

    return render(request, 'index.html')

def admin_login(request):
    msg = ""  # Initialize the message variable
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        # Perform a case-sensitive check with regex for exact username
        user = None
        try:
            db_user = User.objects.get(Q(username__regex=fr'^{username}$'))  # Exact case-sensitive regex match
            user = authenticate(request, username=username, password=password)
            
            if user is not None:
                login(request, user)  # Log the user in
                return redirect('dashboard')  # Redirect to the dashboard
            else:
                msg = "Invalid password. Please try again."
        except User.DoesNotExist:
            msg = "Username does not match any records. Please try again."

    # Render the login page with any error message
    return render(request, 'admin_login.html', {'msg': msg})

def stud_login(request):
    return render(request, 'student_login.html')

def dashboard(request):
    # enquiry_count = Enquiry.objects.count()
    # context ={'enquiry_count':enquiry_count}
    return render(request, 'Dashboard.html')

def batch(request):   
    all_batches = batches.objects.all()
    return render(request, 'batches.html', {'batches': all_batches})

def add_batches(request):
    msg = ''
    if request.method == "POST":
        form = BatchForm(request.POST)
        if form.is_valid():
            form.save()
            msg = 'The Batch has been added.'
            return redirect('batches')
        else:
            msg = 'There was an error adding the batch.'
    else:
        form = BatchForm()

    return render(request, 'add_batches.html', {'form': form, 'msg': msg})

def edit_batch(request, batch_id):
    batch = get_object_or_404(batches, id= batch_id )

    if request.method == 'POST':
        # Update fields with submitted form data
        batch.batch_name = request.POST.get('batch_name')
        batch.course_name = request.POST.get('course_name')
        batch.student_count = request.POST.get('student_count')
        batch.save()  # Save the updated batch to the database
        return redirect('batches')  # Redirect to the batches list or another page

    # Render the edit_batch template with the current batch data
    return render(request, 'edit_batch.html',{'batch':batch})

def deletebatch(request, batch_id):
    if request.method == 'DELETE':
        batch = get_object_or_404(batches, id = batch_id)
        batch.delete()
        return JsonResponse({'success': True})
    return JsonResponse({'success': False}, status=400)

    
def student(request):
    return render(request, 'student.html')

def attendance(request):
    return render(request, 'attendance.html')

def records(request):
    return render(request, 'attendance_records.html')

def enquiry(request):
    enquiries = Enquiry.objects.all()
    return render(request, 'enquiry_manager.html', {'enquiries':enquiries})

def delete_enquiry(request, id):
    if request.method == 'DELETE':
        enquiry = get_object_or_404(Enquiry, id=id)
        enquiry.delete()
        return JsonResponse({'success': True})
    return JsonResponse({'success': False}, status=400)

def staff_manager(request):
    return render(request, 'staff_manager.html')

def satff_admin(request):
    return render(request, 'staff.html')

def edit_staff_details(request):
    return render(request, 'edit_staff_details.html')

def uploads(request):
    return render(request, 'upload.html')

def profile(request):
    return render(request, 'profile.html')

def new_admission(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST, request.FILES)  # Include request.FILES for file upload
        if form.is_valid():
            # Print a success message for debugging
            print("Form is valid. Data:", form.cleaned_data)
            return render(request, 'student.html')  # Redirect to a success page
        else:
            # Log errors to the console for debugging
            print("Form is invalid. Errors:", form.errors)
    else:
        # Initialize the form for GET requests
        form = StudentRegistrationForm()

    return render(request, 'new_admission.html', {'form': form})

def all_students(request):
    return render(request, 'all_students.html')

def inactive_students(request):
    return render(request, 'inactive_students.html')

