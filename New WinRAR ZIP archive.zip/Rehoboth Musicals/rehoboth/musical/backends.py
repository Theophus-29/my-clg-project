from django.contrib.auth.backends import ModelBackend
from django.contrib.auth.models import User

class CaseSensitiveModelBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        try:
            # Perform a case-sensitive lookup for the username
            user = User.objects.get(username__exact=username)
            # If user is found, check the password
            if user.check_password(password):
                return user
        except User.DoesNotExist:
            return None  # Username does not match exactly